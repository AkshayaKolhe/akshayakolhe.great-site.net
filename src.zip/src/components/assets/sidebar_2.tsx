import * as React from 'react';
import '../components/css/sidebar.css'
import Button from '@mui/material/Button'
import Avatar from '@mui/material/Avatar';
import './assets/itsMe.jpg';
import { Routes, Route, Link } from 'react-router-dom';
import 'bootstrap'
import { styled, useTheme } from '@mui/material/styles';
import Drawer from '@mui/material/Drawer';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { useNavigate } from "react-router-dom";
import me from './assets/itsMe.jpg'
const drawerWidth = 240;

function logoutclick() {

}

const Main = styled('main', { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }) => ({
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    marginLeft: `-${drawerWidth}px`,
    ...(open && {
      transition: theme.transitions.create('margin', {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      marginLeft: 0,
    }),
  }),
);

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
  transition: theme.transitions.create(['margin', 'width'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: `${drawerWidth}px`,
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
  justifyContent: 'flex-end',
}));

export default function Sidebar() {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };
  function hideparent() {
    document.getElementById("parent").style.display = 'none'
  }
  const navigate = useNavigate();
const itsme = me;
  return (

    <>
        <Toolbar sx={{height:"0%", width:"0%"}}>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
          >
            <MenuIcon />
          </IconButton>
        </Toolbar>

        <Drawer
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            '& .MuiDrawer-paper': {
              width: drawerWidth,
              boxSizing: 'border-box',
            },
          }}
          variant="persistent"
          anchor="left"
          open={open}
        >
          <DrawerHeader className='bg-dark'>
            <IconButton onClick={handleDrawerClose}>
              {theme.direction === 'ltr' ? <ChevronLeftIcon style={{ color: 'white' }} /> : <ChevronRightIcon />}
            </IconButton>
          </DrawerHeader>
          <div className="h-100 bg-dark ">
            <ul className='example-collapse-text col d-flex flex-column justify-content-center align-items-center mt-3  p-0' id="navbarSupportedContent">

              <li className='row'>
                <Link to="/">
                  <Avatar alt="pratik" src={itsme} />
                </Link>
              </li>
              <li className='row'><Button variant="text" onClick={() => {navigate("/");} }><Link style={{ color: 'white', textDecoration: 'none' }} to="student">Home</Link></Button></li>
              <li className='row'><Button variant="text" onClick={() => {navigate("/student");} }><Link style={{ color: 'white', textDecoration: 'none' }} to="student">Student</Link></Button></li>
              <li className='row'><Button variant="text" onClick={() => {navigate("/teacher");} } ><Link style={{ color: 'white', textDecoration: 'none' }} to="teacher">Teacher</Link></Button></li>
              <li className='row'><Button variant="text" onClick={() => {navigate("/classes");} } ><Link style={{ color: 'white', textDecoration: 'none' }} to='classes'>Classes</Link></Button></li>
              <li className='row'><Button variant="text" onClick={() => {navigate("/admission");} }><Link style={{ color: 'white', textDecoration: 'none' }} to='admission'>Admission</Link></Button></li>
              <li className='row'><Button variant="text" onClick={() => {navigate("/designation");} }><Link style={{ color: 'white', textDecoration: 'none' }} to='designation'>Designation</Link></Button></li>
              <li className='row'><Button variant="contained" onClick={() => {navigate("/logout");} }><Link style={{ color: 'white', textDecoration: 'none' }}>Log Out</Link></Button></li>
            </ul>

          </div>
        </Drawer>
    </>
  )
}
