import React from 'react'

export default function logout() {
  return (
<>

<div>

<h3>thank you for loging in</h3>

</div>
</>
  )
}
