import React from "react";
import ReactDOM from "react-dom/client";
import Box from '@mui/material/Box'
import ToggleButton from '@mui/material/ToggleButton';
import ViewListIcon from '@mui/icons-material/ViewList';
import './css/student.css'
import Classlayout from "../components/classlayout";
import { Link, Route, Routes } from "react-router-dom";
import NavigationSideBar from './sidebar_2.tsx';

function TextLinkExample() {
  let ct = "Class teacher:";

  return (
    <Box sx={{ display: "flex" }}>


      <NavigationSideBar />
      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <div>
          <div className="container list-group listgroup">

            <div className="card">
              <div className="card-header">
                <b>{ct}</b> shubham kahdekar
              </div>
              <div className="card-body">
                <h5 className="card-title">1st standard</h5>
                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <button className="btn btn-primary" data-bs-toggle="modal" href="#data"><Link to="classlayout" style={{ color: 'white', textDecoration: 'none' }} > checkout </Link> </button>
              </div>
            </div>
            <br />
            <div className="card">
              <div className="card-header">
                <b>{ct}</b> shubham kahdekar
              </div>
              <div className="card-body">
                <h5 className="card-title">2nd standard</h5>
                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <button className="btn btn-primary" data-bs-toggle="modal" href="#data"><Link to="classlayout" style={{ color: 'white', textDecoration: 'none' }}> checkout </Link></button>
              </div>
            </div>
            <br />
            <div className="card">
              <div className="card-header">
                <b>{ct}</b> shubham kahdekar
              </div>
              <div className="card-body">
                <h5 className="card-title">3rd standard</h5>
                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <button className="btn btn-primary" data-bs-toggle="modal" href="#data"><Link to="classlayout" style={{ color: 'white', textDecoration: 'none' }}> checkout </Link></button>
              </div>
            </div>
            <br />
            <div className="card">
              <div className="card-header">
                <b>{ct}</b> shubham kahdekar
              </div>
              <div className="card-body">
                <h5 className="card-title">4th standard</h5>
                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <button className="btn btn-primary" data-bs-toggle="modal" href="#data"><Link to="classlayout" style={{ color: 'white', textDecoration: 'none' }}> checkout </Link></button>
              </div>
            </div>
            <br />
            <div className="card">
              <div className="card-header">
                <b>{ct}</b> shubham kahdekar
              </div>
              <div className="card-body">
                <h5 className="card-title">5th standard</h5>
                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <button className="btn btn-primary" data-bs-toggle="modal" href="#data"><Link to="classlayout" style={{ color: 'white', textDecoration: 'none' }}> checkout </Link></button>
              </div>
            </div>
            <br />
            <div className="card">
              <div className="card-header">
                <b>{ct}</b> shubham kahdekar
              </div>
              <div className="card-body">
                <h5 className="card-title">6th standard</h5>
                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <button className="btn btn-primary" data-bs-toggle="modal" href="#data"><Link to="classlayout" style={{ color: 'white', textDecoration: 'none' }}> checkout </Link></button>
              </div>
            </div>
            <br />
            <div className="card">
              <div className="card-header">
                <b>{ct}</b> shubham kahdekar
              </div>
              <div className="card-body">
                <h5 className="card-title">7th standard</h5>
                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <button className="btn btn-primary" data-bs-toggle="modal" href="#data"><Link to="classlayout" style={{ color: 'white', textDecoration: 'none' }}> checkout </Link></button>
              </div>
            </div>
            <br />
            <div className="card">
              <div className="card-header">
                <b>{ct}</b> shubham kahdekar
              </div>
              <div className="card-body">
                <h5 className="card-title">8th standard</h5>
                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <button className="btn btn-primary" data-bs-toggle="modal" href="#data"><Link to="classlayout" style={{ color: 'white', textDecoration: 'none' }}> checkout </Link></button>
              </div>
            </div>
            <br />
            <div className="card">
              <div className="card-header">
                <b>{ct}</b> shubham kahdekar
              </div>
              <div className="card-body">
                <h5 className="card-title">9th standard</h5>
                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <button className="btn btn-primary" data-bs-toggle="modal" href="#data"><Link to="classlayout" style={{ color: 'white', textDecoration: 'none' }}> checkout </Link></button>
              </div>
            </div>
            <br />
            <div className="card">
              <div className="card-header">
                <b>{ct}</b> shubham kahdekar
              </div>
              <div className="card-body">
                <h5 className="card-title">10th standard</h5>
                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <button className="btn btn-primary" data-bs-toggle="modal" href="#data"><Link to="classlayout" style={{ color: 'white', textDecoration: 'none' }}> checkout </Link></button>
              </div>
            </div>
            <br />

          </div>
          <div class="modal fade modal-xl" id="data" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <Routes>
                    <Route path="classlayout" element={<Classlayout />}>
                    </Route>
                  </Routes>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Box>

    </Box>


  );
}

export default TextLinkExample;