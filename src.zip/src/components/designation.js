import React from 'react';
import { Col, Stack } from 'react-bootstrap';
import './css/designation.css';
import 'bootstrap';
import ToggleButton from '@mui/material/ToggleButton';
import ViewListIcon from '@mui/icons-material/ViewList';
import NavigationSideBar from './sidebar_2.tsx';
import { Box } from '@mui/material';
export default function designation() {
    return (
        <>
            <Box sx={{ display: "flex" }}>


                <NavigationSideBar />
                <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
                    <div class="container list-group listgroup">

                        <div class="row">
                            <a href="#" class=" col list-group-item list-group-item-action" aria-current="true">


                                <div class="d-flex w-100 justify-content-between">
                                    <h5 class="mb-1">Pratik Prashant Kolhe</h5>
                                    <small>Front End Developer</small>
                                </div>
                                <p class="mb-1"> <b> Designation:- </b> Developer </p>
                                <small>Admin Panel</small>
                            </a>
                            <ToggleButton className='col col-xxl-1' value="list" aria-label="list">
                                <ViewListIcon />
                            </ToggleButton>
                        </div>
                        <br />


                        <div class="row">
                            <a href="#" class="col list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h5 class="mb-1">Rohan Sanjay Ghuge</h5>
                                    <small class="text-muted">Backend Developer</small>
                                </div>
                                <p class="mb-1"> <b>Designation:-</b> Developer </p>
                                <small class="text-muted">Datanase Handle</small>
                            </a>
                            <ToggleButton className='col col-xxl-1' value="list" aria-label="list">
                                <ViewListIcon />
                            </ToggleButton>
                        </div>
                    </div>
                </Box>
            </Box>
        </>
    )
}
