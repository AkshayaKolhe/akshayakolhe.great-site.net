import React from 'react'
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import 'bootstrap';
export default function Classlayout() {

  return (
    <div>
      <table class="table-striped table">
  <thead>
    <tr>
      <th scope="col" className='col-md-2 col-xl-1'>Roll No</th>
      <th scope="col" className='col-md-6 col-xl-2 col-sm-6'>Name</th>
      <th scope="col" className='col-md-3 col-xl-2 col-sm-3'>Contact No</th>
      <th scope="col" className='col-md-4 col-xl-1'>Fees</th>
      <th scope="col" className='col-md-2 col-xl-2'></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>varun sandip tipkari</td>
      <td>8530458123</td>
      <td>10000/20000</td>
      <td><Button startIcon={<EditIcon />}>
      </Button><Button startIcon={<DeleteIcon />}>
      </Button></td>
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>varun sandip tipkari</td>
      <td>8530458123</td>
      <td>10000/20000</td>
      <td><Button startIcon={<EditIcon />}>
      </Button><Button startIcon={<DeleteIcon />}>
      </Button></td>
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>varun sandip tipkari</td>
      <td>8530458123</td>
      <td>10000/20000</td>
      <td><Button startIcon={<EditIcon />}>
      </Button><Button startIcon={<DeleteIcon />}>
      </Button></td>
    </tr>
  </tbody>
</table>
    </div>
  )
}
