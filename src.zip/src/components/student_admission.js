import React from 'react'
import TextField from '@mui/material/TextField';
import { useState } from 'react';
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import KeyIcon from '@mui/icons-material/Key';
import Button from '@mui/material/Button';
import FormHelperText from '@mui/material/FormHelperText';


// For database entry
const initialValue = {
    name: '',
    dob: '',
    std: '',
    contactno: '',
    alternateno: '',
    address: '',
    email: '',
    uname: '',
    pass: '',
    schoolname:''
}


const boxstyle = {
    // border: '2px solid black',

    width: '60vw'
}
const textstyle = {
    color: 'white'
}
var password = document.getElementById("password");

const ValidateMobileNumber = (event, id) => {
    var mobileNumber = event.target.value
    // var mobileNumber1 = id
    // console.log(mobileNumber1);

    var expr = /^(0|91)?[6-9][0-9]{9}$/;
    if (!expr.test(mobileNumber)) {
        document.getElementById(id).style.color = 'red'
    }
    else {
        document.getElementById(id).style.color = 'black'
    }
}

const Admission = () => {
    var password = "";

    function genPassword() {
        var chars = "0123456789";
        var passwordLength = 5;
        for (var i = 0; i <= passwordLength; i++) {
            var randomNumber = Math.floor(Math.random() * chars.length);
            password += chars.substring(randomNumber, randomNumber + 1);
        }
        document.getElementById("password").value = password;
        setStudent({ ...student, ["pass"]: password })

    }

    const handleChange = (event) => {
        setStd(event.target.value);
        setStudent({ ...student, [event.target.name]: event.target.value })

    };
    const [Std2, setStd] = useState('');
    const [open, setOpen] = useState(false);
    const [username, Setuname] = useState('');

    const [student, setStudent] = useState(initialValue);
    const { name, dob, std, contactno, alternateno, address, email, uname, pass, schoolname } = student;
    // setStudent({std:Std})

    const onValueChange2 = (event, id) => {
        var mobileNumber = event.target.value
        // var mobileNumber1 = id
        // console.log(mobileNumber1);

        var expr = /^(0|91)?[6-9][0-9]{9}$/;
        if (!expr.test(mobileNumber)) {
            document.getElementById(id).style.color = 'red'
        }
        else {
            document.getElementById(id).style.color = 'black'
        }
        setStudent({ ...student, [event.target.name]: event.target.value })
        console.log(student);

    }

    const onValueChange = (event) => {

        setStudent({ ...student, [event.target.name]: event.target.value })
        console.log(student);
    }

    function submit() {
        console.log(student);
    }
    const emailfilled = (event) => {
        Setuname(event.target.value);
    }
    const handleClose = () => {
        setOpen(false);
    };

    const handleOpen = () => {
        setOpen(true);
    };

    return (
   
        <form className="container row g-3">

        <div className="col">
          <TextField id="name" name='name' fullWidth required label="Name" variant="outlined" className='mb-3' style={textstyle} onChange={(event) => onValueChange(event)} />
        </div>

        <div className='col-12'>
        <FormControl fullWidth>
                 <TextField type='date' name='dob' required variant='outlined' style={textstyle} onChange={(event) => onValueChange(event)} />
                         <FormHelperText id="outlined-weight-helper-text">Date of Birth</FormHelperText>
                     </FormControl>
        </div>
          
        <div className='col-12'>
        <FormControl sx={{ width:'100%' }} className='mt-3'>
                        <InputLabel id="demo-controlled-open-select-label1" >Std</InputLabel>
                        <Select
                            labelId="demo-controlled-open-select-label"
                             id="demo-controlled-open-select"
                            open={open}
                            name='std'
                            onClose={handleClose}
                            onOpen={handleOpen}
                            value={Std2}
                             label="Std"
                             onChange={handleChange}
                       >
                       <MenuItem value={1}>1st</MenuItem>
                             <MenuItem value={2}>2nd</MenuItem>
                             <MenuItem value={3}>3rd</MenuItem>
                            <MenuItem value={4}>4th</MenuItem>
                            <MenuItem value={5}>5th</MenuItem>
                             <MenuItem value={6}>6th</MenuItem>
                             <MenuItem value={7}>7th</MenuItem>
                            <MenuItem value={8}>8th</MenuItem>
                            <MenuItem value={9}>9th</MenuItem>
                          <MenuItem value={10}>10th</MenuItem>

                        </Select>
            </FormControl>
        </div>

          <div class="col-12">
          <TextField  fullWidth variant='outlined' name='schoolname' id='schoolname' label="School Name" required className='d-block mt-3' onChange={(event) => onValueChange(event)} />
          </div>
          <div class="col-12">
          <TextField  fullWidth variant='outlined' name='contactno' id='contactno1' label="Contact No" required className='d-block mt-3' inputProps={{ inputMode: 'numeric' }} onChange={(event) => onValueChange2(event, "contactno1")} />
          </div>
          <div class="col-12">
          <TextField fullWidth variant='outlined' name='alternateno' id='contactno2' label="Alternate No" className='mt-3 ' inputProps={{ inputMode: 'numeric', pattern: '/^(0|91)?[6-9][0-9]{9}$/' }} onChange={(event) => onValueChange2(event, "contactno2")} />
          </div>


        <div className='col-12'>
        <TextField fullWidth required variant='outlined' name='address' id='address' label='Address' className='mt-3' multiline maxRows={4} onChange={(event) => onValueChange(event)}></TextField>
        </div>

        <div className="row g-3">
          <div className="col-md-6">
          <div className="input-group mt-3">
                      <input type="text" className="form-control" placeholder="Email" aria-describedby="basic-addon2" id='email' name='email' onChange={(event) => onValueChange(event)} />
                         <span className="input-group-text " id="basic-addon2">@gmail.com</span>
                     </div>

          </div>
          <div className="col-md-6">
          <div className="input-group mt-3">
                        <span className="input-group-text" id="basic-addon1">@</span>
                        <input type="text" name='uname' className="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" onChange={(event) => onValueChange(event)} />
                    </div>
          </div>
        </div>

        <div className='row g-3'>
            <div className='col-md-6'>
            <TextField
                             name='pass'
                             id="password"
                             label="Password"
                             fullWidth
                             defaultValue="Generate"
                             InputProps={{
                                 readOnly: true,
                         }}
                             onChange={(event)=>onValueChange(event)}
                             required
                             variant="outlined"
                         />
            </div>
            <div className='col-md-6'>
            <Button className='mx-3 mt-2' style={{ color: 'black' }} onClick={genPassword} endIcon={<KeyIcon />}>
                             Create Password
                         </Button>
            </div>
        </div>
        <div className="col-12">
        <button type='button' className='btn btn-primary mb-5' onClick={submit}>ADMIT</button>
        </div>

      </form>
    )
}

export default Admission;