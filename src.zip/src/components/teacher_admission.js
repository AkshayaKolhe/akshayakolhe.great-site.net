import * as React from 'react';
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import KeyIcon from '@mui/icons-material/Key';
import Button from '@mui/material/Button';
import FormHelperText from '@mui/material/FormHelperText';
import TextField from '@mui/material/TextField';
import { useTheme } from "@mui/material/styles";
import OutlinedInput from "@mui/material/OutlinedInput";
import 'bootstrap';
import InputLabel from '@mui/material/InputLabel';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};




// For database entry
const initialValue = {
  name: '',
  dob: '',
  stdassigned: '',
  contactno: '',
  alternateno: '',
  address: '',
  email: '',
  uname: '',
  pass: '',
  languageknown: '',
  experties: '',
  experience: '',
  subjects:''
}

const textstyle = {
  color: 'white'
}
var password = document.getElementById("password");

const ValidateMobileNumber = (event, id) => {
  var mobileNumber = event.target.value
  // var mobileNumber1 = id
  // console.log(mobileNumber1);

  var expr = /^(0|91)?[6-9][0-9]{9}$/;
  if (!expr.test(mobileNumber)) {
    document.getElementById(id).style.color = 'red'
  }
  else {
    document.getElementById(id).style.color = 'black'
  }
}
const names = ["Marathi", "HIndi", "English"];


function getStyles(name, language, theme) {
  return {
    fontWeight:
      language.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium
  };
}

function getStylesstd(name, standard, theme) {
  return {
    fontWeight:
      standard.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

const standards = [
  'First',
  'Second',
  'Third',
  'Fourth',
  'Fifth',
  'Sixth',
  'Seventh',
  'Eight',
  'Ninth',
  'Tenth',
];

export default function Admission() {


  const [language, setLanguage] = React.useState([]);
  const theme = useTheme();
  var password = "";
  const [standard, setstandard] = React.useState([]);

  const handleChangestd = (event) => {
    const {
      target: { value },
    } = event;
    setstandard(
      // On autofill we get a stringified value.
      typeof value === 'string' ? value.split(',') : value,
    );

    }

    function genPassword() {
      var chars = "0123456789";
      var passwordLength = 5;
      for (var i = 0; i <= passwordLength; i++) {
        var randomNumber = Math.floor(Math.random() * chars.length);
        password += chars.substring(randomNumber, randomNumber + 1);
      }
      document.getElementById("password").value = password;
      setteacher({ ...teacher, ["pass"]: password })

    }

    const handleChange = (event) => {
      setStd(event.target.value);
      setteacher({ ...teacher, [event.target.name]: event.target.value })

    };
    const [Std2, setStd] = React.useState('');
    const [open, setOpen] = React.useState(false);
    const [username, Setuname] = React.useState('');

    const [teacher, setteacher] = React.useState(initialValue);
    const { name, dob, stdassigned, contactno, alternateno, address, email, uname, pass, languageknown, experties, experience, subjects } = teacher;
    // setteacher({std:Std})

    const onValueChange2 = (event, id) => {
      var mobileNumber = event.target.value
      // var mobileNumber1 = id
      // console.log(mobileNumber1);

      var expr = /^(0|91)?[6-9][0-9]{9}$/;
      if (!expr.test(mobileNumber)) {
        document.getElementById(id).style.color = 'red'
      }
      else {
        document.getElementById(id).style.color = 'black'
      }
      setteacher({ ...teacher, [event.target.name]: event.target.value })
      console.log(teacher);

    }

    const onValueChange = (event) => {

      setteacher({ ...teacher, [event.target.name]: event.target.value })
      console.log(teacher);
    }

    function submit() {
      console.log(teacher);
    }
    const emailfilled = (event) => {
      Setuname(event.target.value);
    }
    const handleClose = () => {
      setOpen(false);
    };

    const handleOpen = () => {
      setOpen(true);
    };

    const handleShift = (event) => {
      const {
        target: { value },
      } = event;
      setteacher({ ...teacher, [event.target.name]: event.target.value })

      setLanguage(
        // On autofill we get a stringified value.
        typeof value === "string" ? value.split(",") : value
      );
    };

    return (

      <form className="container row g-3">
        {/* Name Input */}
        <div className="col">
          <TextField id="name" name='name' fullWidth required label="Name" variant="outlined" className='mb-3' style={textstyle} onChange={(event) => onValueChange(event)} />
        </div>

        {/* Birth date input */}
        <div className='col-12'>
          <FormControl fullWidth>
            <FormHelperText id="outlined-weight-helper-text">Date of Birth</FormHelperText>
            <TextField type='date' name='dob' required variant='outlined' style={textstyle} onChange={(event) => onValueChange(event)} />
          </FormControl>
        </div>

        {/* Known Language */}
          <div className='col-12'>

            <FormControl style={{width:'100%'}}>
              <Select
                multiple
                displayEmpty
                value={language}
                name='languageknown'
                onChange={handleShift}
                input={<OutlinedInput />}
                renderValue={(selected) => {
                  if (selected.length === 0) {
                    return <em>Konown Languages</em>;
                  }
                  return selected.join(", ");
                }}
                MenuProps={MenuProps}
                inputProps={{ "aria-label": "Without label" }}
              >
                <MenuItem disabled value="">
                  <em>Known languages</em>
                </MenuItem>
                {names.map((name) => (
                  <MenuItem
                    key={name}
                    value={name}
                    style={getStyles(name, language, theme)}
                  >
                    {name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>


          </div>
           
           <div className='col-12'>
            <FormControl style={{width:'100%'}}>
              <InputLabel id="demo-multiple-name-label">Assigned Classes</InputLabel>
              <Select
                labelId="demo-multiple-name-label"
                id="demo-multiple-name"
                multiple
                value={standard}
                onChange={handleChangestd}
                input={<OutlinedInput label="Assigned Classes" />}
                MenuProps={MenuProps}
              >
                {standards.map((name) => (
                  <MenuItem
                    key={name}
                    value={name}
                    style={getStylesstd(name, standard, theme)}
                  >
                    {name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            </div>


        <div className='col-12'>
          <TextField fullWidth variant='outlined' name='experties' id='experties' label="Experties" required className='d-block' inputProps={{ inputMode: 'string' }} onChange={(event) => onValueChange(event)} />
        </div>

        <div className='col-12'>
          <TextField fullWidth variant='outlined' name='experience' id='experience' label="Experience" className='d-block' inputProps={{ inputMode: 'numeric' }} onChange={(event) => onValueChange(event)} />
        </div>

        <div className='col-12'>
          <TextField fullWidth variant='outlined' name='subjects' id='subjects' label="subjects" className='d-block' inputProps={{ inputMode: 'string' }} onChange={(event) => onValueChange(event)} />
        </div>

        <div className="col-12">
          <TextField fullWidth variant='outlined' name='contactno' id='contactno1' label="Contact No" required className='d-block' inputProps={{ inputMode: 'numeric' }} onChange={(event) => onValueChange2(event, "contactno1")} />
        </div>

        <div className="col-12">
          <TextField fullWidth variant='outlined' name='alternateno' id='contactno2' label="Alternate No" className='  ' inputProps={{ inputMode: 'numeric', pattern: '/^(0|91)?[6-9][0-9]{9}$/' }} onChange={(event) => onValueChange2(event, "contactno2")} />
        </div>


        <div className='col-12'>
          <TextField fullWidth required variant='outlined' name='address' id='address' label='Address' className=' ' multiline maxRows={4} onChange={(event) => onValueChange(event)}></TextField>
        </div>


        <div className="col-md-6">
          <div className="input-group  ">
            <input type="text" className="form-control" placeholder="Email" aria-describedby="basic-addon2" id='email' name='email' onChange={(event) => onValueChange(event)} />
            <span className="input-group-text " id="basic-addon2">@gmail.com</span>
          </div>

        </div>
        <div className="col-md-6">
          <div className="input-group  ">
            <span className="input-group-text" id="basic-addon1">@</span>
            <input type="text" name='uname' className="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" onChange={(event) => onValueChange(event)} />
          </div>
        </div>


        <div className='row g-2'>
          <div className='col-md-6'>
            <TextField
              name='pass'
              id="password"
              label="Password"
              fullWidth
              defaultValue="Generate"
              InputProps={{
                readOnly: true,
              }}
              onChange={(event) => onValueChange(event)}
              required
              variant="outlined"
            />
          </div>
          <div className='col-md-6'>
            <Button className='mx-3 mt-2' style={{ color: 'black' }} onClick={genPassword} endIcon={<KeyIcon />}>
              Create Password
            </Button>
          </div>
        </div>
        <div className="col-12">
          <button type='button' className='btn btn-primary mb-5' onClick={submit}>ADMIT</button>
        </div>

      </form>
    )
  }