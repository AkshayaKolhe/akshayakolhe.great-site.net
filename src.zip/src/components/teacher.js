import React from 'react';
import ToggleButton from '@mui/material/ToggleButton';
import ViewListIcon from '@mui/icons-material/ViewList';
import { Box } from '@mui/material';
import NavigationSideBar from './sidebar_2.tsx';

export default function Teacher() {

    return (

        <>
            <Box sx={{ display: "flex" }}>


                <NavigationSideBar />
                <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
                    <div class="container list-group listgroup">

                        <div class="row">
                            <a href="#" class=" col list-group-item list-group-item-action" aria-current="true">


                                <div class="d-flex w-100 justify-content-between">
                                    <h5 class="mb-1">Shubham Khadekar</h5>
                                    <small>Marathi</small>
                                </div>
                                <p class="mb-1"> <b> Designation:- </b> teacher </p>
                                <small><b>Classes:-</b>1,10</small>
                            </a>
                            <ToggleButton className='col col-xxl-1' value="list" aria-label="list">
                                <ViewListIcon />

                            </ToggleButton>
                        </div>
                        <br />


                        <div class="row">
                            <a href="#" class="col list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h5 class="mb-1">Pranav Mirkar</h5>
                                    <small class="text-muted">English</small>
                                </div>
                                <p class="mb-1"> <b>Designation:-</b> teacher </p>
                                <small class="text-muted"><b>Classes:-</b>5,10</small>
                            </a>
                            <ToggleButton className='col col-xxl-1' value="list" aria-label="list">
                                <ViewListIcon />
                            </ToggleButton>
                        </div>
                    </div>

                </Box>
            </Box>
        </>
    )

}