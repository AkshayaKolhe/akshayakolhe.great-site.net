import * as React from 'react';
import 'bootstrap';
import { Button } from '@mui/material';
import './App.css';
import Teacher from "./components/teacher"
import Student from "./components/student.js";
import Classes from "./components/classes.js";
import Admission from './components/admission.js';
import Designation from "./components/designation";
import Homepage from './components/homepage.js';
import Profile from './components/profile';
import { Route, Routes } from "react-router-dom";

export default function App() {
  return (
    <>
      <div >


        <Routes>

          <Route path="/" index element={<Homepage />}></Route>
          <Route path="classes/*" index element={<Classes />}></Route>
          <Route path="teacher" element={<Teacher />}>  </Route>
          <Route path="student" element={<Student />}>  </Route>
          <Route path="admission" element={<Admission />}>  </Route>
          <Route path="Designation" element={<Designation />}>  </Route>
          <Route path="profile" element={<Profile />}>  </Route>

        </Routes>
      </div>
    </>
  );
}

